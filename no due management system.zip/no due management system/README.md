#Student Management System Using Mysql with php.

How to run this Project
	1. Download and Unzip the file on your local system copy student-management folder.
	2. Put student-management folder inside the root directory [C:\xampp\htdocs]
Database Configuration
	Open phpmyadmin [http://localhost/phpmyadmin]
	Create Database [project_dbms]
	Import database project_dbms.sql (available inside the zip package[student-management\database])

For Student Login
	1.Open Your browser put inside browser [“http://localhost/student-management”].
	2.Give your class roll number[If there is no match check the database roll numbers].
	3.For details ->Click the [Student login] button.
	4.Your passsword is also your roll number. 

For Admin login
	1.Open Your browser put inside browser [“http://localhost/student-management”].
	3.Click the [Admin login] button to log in.
	Login Details for admin :
		Username: demoadmin
		Password: demoadmin
	4.Can register by click in the register form and submitting required data.

If you face any problem,contact me at facebook.
- MD. Mehedi hasan
					[Happy Debugging]
