<?php 
define('DBHOST', 'localhost');
define('DBUSER', 'root');
define('DBNAME', 'project_dbms');


$db_con = mysqli_connect(DBHOST, DBUSER, '', DBNAME);
