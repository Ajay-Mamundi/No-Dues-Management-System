-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2023 at 10:19 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_dbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_me`
--

CREATE TABLE `about_me` (
  `about_me_id` int(20) NOT NULL,
  `roll_id` int(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  `name_father` varchar(40) NOT NULL,
  `name_mother` varchar(40) NOT NULL,
  `number` varchar(20) NOT NULL,
  `blood_group` varchar(20) NOT NULL,
  `session` int(20) NOT NULL,
  `department_code` varchar(20) NOT NULL,
  `hall_code` varchar(10) NOT NULL,
  `gender` enum('Male','Female','Other''s') NOT NULL,
  `emergency_number` varchar(20) DEFAULT NULL,
  `emergency_number_holder` varchar(20) DEFAULT NULL,
  `photo` varchar(50) NOT NULL,
  `date_of_birth` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `about_me`
--

INSERT INTO `about_me` (`about_me_id`, `roll_id`, `name`, `name_father`, `name_mother`, `number`, `blood_group`, `session`, `department_code`, `hall_code`, `gender`, `emergency_number`, `emergency_number_holder`, `photo`, `date_of_birth`) VALUES
(28, 2106, 'AJAY M', 'm', 'n', '', 'B', 2025, '1', '01', 'Male', '', 'father', '21062023-03-24-03-00.jpg', '0000-00-00'),
(29, 2121, 'dhanush', 'dfhs', 'gsd', '', 'e', 32, '2', '01', 'Male', '', 'father', '21212023-04-18-04-38.jpg', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `course_information`
--

CREATE TABLE `course_information` (
  `course_id` int(11) NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `credits` enum('1','2','3') NOT NULL,
  `course_title` varchar(150) NOT NULL DEFAULT '',
  `marks` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_information`
--

INSERT INTO `course_information` (`course_id`, `course_code`, `credits`, `course_title`, `marks`) VALUES
(1, '18CSC202J', '2', 'OBJECT ORIENTED PROGRAMMING', '50.00'),
(2, '18CSC201J', '3', 'DATA STRUCTURES AND ALGORITHMS', '75.00'),
(3, '18MAB201T', '3', 'PSQT', '75.00'),
(4, '18CSC203J', '3', 'CAO', '75.00'),
(5, '18MBM20L', '1', 'APTITUDE', '25.00'),
(6, '18CSC204J', '1', 'MINOR PROJECT', '25.00');

-- --------------------------------------------------------

--
-- Table structure for table `course_wise_result`
--

CREATE TABLE `course_wise_result` (
  `course_result_id` int(20) NOT NULL,
  `result_id` int(20) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `cgpa` double NOT NULL DEFAULT 0,
  `tried` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `department_info`
--

CREATE TABLE `department_info` (
  `department_code` varchar(20) NOT NULL,
  `department_name` varchar(100) NOT NULL,
  `department_building` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department_info`
--

INSERT INTO `department_info` (`department_code`, `department_name`, `department_building`) VALUES
('1', 'CSE', 'APJ BLOCK'),
('2', 'AIML', 'RK BLOCK'),
('3', 'CSBS', 'APJ BLOCK'),
('4', 'EEE', 'APJ BLOCK'),
('8', 'it', 'rk block');

-- --------------------------------------------------------

--
-- Table structure for table `hall_info`
--

CREATE TABLE `hall_info` (
  `hall_code` varchar(10) NOT NULL,
  `hall_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hall_info`
--

INSERT INTO `hall_info` (`hall_code`, `hall_name`) VALUES
('01', 'NAYIDU HALL'),
('02', 'APJ HALL'),
('03', 'VIVEKANANDHA HALL'),
('04', 'NEHRU HALL'),
('05', 'KAMBAR HALL'),
('06', 'KRISHNA HALL'),
('07', 'RAMAR HALL'),
('08', 'MANI HALL'),
('09', 'KISHORE HALL'),
('10', 'JEGAN HALL'),
('11', 'JEEVA HALL'),
('20', 'KIRAN HALL'),
('21', 'AJAY HALL');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(20) NOT NULL,
  `about_me_id` int(20) NOT NULL,
  `student_notice_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `result_id` int(20) NOT NULL,
  `about_me_id` int(20) NOT NULL,
  `year` enum('1st','2nd','3rd','4th') NOT NULL,
  `semester` enum('1st','2nd') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_notice`
--

CREATE TABLE `student_notice` (
  `student_notice_id` int(20) NOT NULL,
  `department_code` varchar(20) NOT NULL,
  `notice_year` enum('1st','2nd','3rd','4th') NOT NULL,
  `notice_semester` enum('1st','2nd') NOT NULL,
  `type_of_notice` enum('Exam','Payment','Result','Vacation','Other''s') NOT NULL,
  `title` varchar(500) NOT NULL,
  `details` longtext NOT NULL,
  `due_date` date NOT NULL COMMENT 'Date or final date the notice will get executed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_notice`
--

INSERT INTO `student_notice` (`student_notice_id`, `department_code`, `notice_year`, `notice_semester`, `type_of_notice`, `title`, `details`, `due_date`) VALUES
(23, '1', '1st', '1st', '', 'Human Computer Interaction', 'Completed', '2023-04-19');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `photo` varchar(50) NOT NULL,
  `status` varchar(12) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `password`, `photo`, `status`, `datetime`) VALUES
(22, 'AJAY M', '927621bcs006@mkce.ac.in', 'gokul_aarav', 'cf9ebd69dd0002fb4aa1401b064c4f5c60dc3401', 'gokul_aarav59-03-23-03-2023IMG-20211129-WA0016.jpg', 'active', '2022-11-23 08:04:35'),
(23, 'AJAY M', 'ajaymamundi@gmail.com', '927621bcs006', '7ca558293c472ff465525e9a49b74590f5d61f28', '927621bcs006.jpg', 'inactive', '2023-03-24 16:25:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_me`
--
ALTER TABLE `about_me`
  ADD PRIMARY KEY (`about_me_id`),
  ADD UNIQUE KEY `roll_id` (`roll_id`),
  ADD KEY `department_code` (`department_code`),
  ADD KEY `hall_code` (`hall_code`);

--
-- Indexes for table `course_information`
--
ALTER TABLE `course_information`
  ADD PRIMARY KEY (`course_id`),
  ADD UNIQUE KEY `unique_course` (`course_code`,`credits`,`course_title`);

--
-- Indexes for table `course_wise_result`
--
ALTER TABLE `course_wise_result`
  ADD PRIMARY KEY (`course_result_id`),
  ADD UNIQUE KEY `unique_result` (`result_id`,`course_id`),
  ADD KEY `result_id` (`result_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `department_info`
--
ALTER TABLE `department_info`
  ADD PRIMARY KEY (`department_code`),
  ADD UNIQUE KEY `department_code` (`department_code`);

--
-- Indexes for table `hall_info`
--
ALTER TABLE `hall_info`
  ADD PRIMARY KEY (`hall_code`),
  ADD UNIQUE KEY `hall_code` (`hall_code`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD UNIQUE KEY `unique_payment` (`about_me_id`,`student_notice_id`),
  ADD KEY `student_notice_id` (`student_notice_id`),
  ADD KEY `about_me_id` (`about_me_id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`result_id`),
  ADD UNIQUE KEY `unique_result_id` (`about_me_id`,`year`,`semester`),
  ADD KEY `about_me_id` (`about_me_id`);

--
-- Indexes for table `student_notice`
--
ALTER TABLE `student_notice`
  ADD PRIMARY KEY (`student_notice_id`),
  ADD KEY `department_code` (`department_code`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_me`
--
ALTER TABLE `about_me`
  MODIFY `about_me_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `course_information`
--
ALTER TABLE `course_information`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `course_wise_result`
--
ALTER TABLE `course_wise_result`
  MODIFY `course_result_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `result_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `student_notice`
--
ALTER TABLE `student_notice`
  MODIFY `student_notice_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `about_me`
--
ALTER TABLE `about_me`
  ADD CONSTRAINT `about_me_ibfk_1` FOREIGN KEY (`department_code`) REFERENCES `department_info` (`department_code`) ON UPDATE CASCADE,
  ADD CONSTRAINT `about_me_ibfk_2` FOREIGN KEY (`hall_code`) REFERENCES `hall_info` (`hall_code`) ON UPDATE CASCADE;

--
-- Constraints for table `course_wise_result`
--
ALTER TABLE `course_wise_result`
  ADD CONSTRAINT `course_wise_result_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `course_information` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `course_wise_result_ibfk_2` FOREIGN KEY (`result_id`) REFERENCES `result` (`result_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`student_notice_id`) REFERENCES `student_notice` (`student_notice_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_ibfk_3` FOREIGN KEY (`about_me_id`) REFERENCES `about_me` (`about_me_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `result`
--
ALTER TABLE `result`
  ADD CONSTRAINT `result_ibfk_1` FOREIGN KEY (`about_me_id`) REFERENCES `about_me` (`about_me_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student_notice`
--
ALTER TABLE `student_notice`
  ADD CONSTRAINT `student_notice_ibfk_1` FOREIGN KEY (`department_code`) REFERENCES `department_info` (`department_code`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
